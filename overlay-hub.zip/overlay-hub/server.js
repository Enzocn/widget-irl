require('dotenv').config();
const express = require('express');
const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 8090;
const CONTROL_KEY = process.env.CONTROL_KEY || 'troque-isso';
const STATE_PATH = path.join(__dirname, 'state.json');

// ---------- Estado (persistido em disco) ----------
function readState() {
  return JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
}
function writeState(state) {
  fs.writeFileSync(STATE_PATH, JSON.stringify(state, null, 2));
}

// Mescla parcial (deep merge de 1 nivel, que e o suficiente para nosso schema)
function mergeState(current, patch) {
  const next = { ...current };
  for (const key of Object.keys(patch)) {
    if (
      typeof patch[key] === 'object' &&
      patch[key] !== null &&
      !Array.isArray(patch[key])
    ) {
      next[key] = { ...current[key], ...patch[key] };
    } else {
      next[key] = patch[key];
    }
  }
  return next;
}

// ---------- Rotas publicas (o overlay le sem chave) ----------
app.get('/api/state', (req, res) => {
  res.json(readState());
});

app.use(express.static(path.join(__dirname, 'public')));

app.get('/overlay', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'overlay.html'));
});

// ---------- Rotas protegidas (painel de controle) ----------
function requireKey(req, res, next) {
  const key = req.query.key || req.headers['x-control-key'];
  if (key !== CONTROL_KEY) {
    return res.status(401).json({ error: 'chave invalida' });
  }
  next();
}

app.get('/control', requireKey, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'control.html'));
});

app.post('/api/state', requireKey, (req, res) => {
  const current = readState();
  const next = mergeState(current, req.body || {});
  writeState(next);
  res.json(next);
});

// ---------- Checagem de "quem esta ao vivo" ----------
let twitchToken = null;
let twitchTokenExpiry = 0;

async function getTwitchToken() {
  if (twitchToken && Date.now() < twitchTokenExpiry) return twitchToken;
  if (!process.env.TWITCH_CLIENT_ID || !process.env.TWITCH_CLIENT_SECRET) return null;
  const resp = await fetch(
    `https://id.twitch.tv/oauth2/token?client_id=${process.env.TWITCH_CLIENT_ID}&client_secret=${process.env.TWITCH_CLIENT_SECRET}&grant_type=client_credentials`,
    { method: 'POST' }
  );
  const data = await resp.json();
  if (!data.access_token) return null;
  twitchToken = data.access_token;
  twitchTokenExpiry = Date.now() + (data.expires_in - 60) * 1000;
  return twitchToken;
}

async function isTwitchLive() {
  try {
    const token = await getTwitchToken();
    if (!token) return false;
    const resp = await fetch(
      `https://api.twitch.tv/helix/streams?user_login=${process.env.TWITCH_USER_LOGIN}`,
      {
        headers: {
          'Client-Id': process.env.TWITCH_CLIENT_ID,
          Authorization: `Bearer ${token}`,
        },
      }
    );
    const data = await resp.json();
    return Array.isArray(data.data) && data.data.length > 0;
  } catch (e) {
    console.error('Erro checando Twitch:', e.message);
    return false;
  }
}

async function isKickLive() {
  try {
    if (!process.env.KICK_CHANNEL) return false;
    const resp = await fetch(
      `https://kick.com/api/v2/channels/${process.env.KICK_CHANNEL}`,
      { headers: { 'User-Agent': 'Mozilla/5.0' } }
    );
    if (!resp.ok) return false;
    const data = await resp.json();
    return !!data.livestream;
  } catch (e) {
    console.error('Erro checando Kick (a Cloudflare da Kick pode bloquear chamadas de servidor):', e.message);
    return false;
  }
}

async function isYoutubeLive() {
  try {
    if (!process.env.YOUTUBE_API_KEY || !process.env.YOUTUBE_CHANNEL_ID) return false;
    const resp = await fetch(
      `https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=${process.env.YOUTUBE_CHANNEL_ID}&eventType=live&type=video&key=${process.env.YOUTUBE_API_KEY}`
    );
    const data = await resp.json();
    return Array.isArray(data.items) && data.items.length > 0;
  } catch (e) {
    console.error('Erro checando YouTube:', e.message);
    return false;
  }
}

async function checkWhoIsLive() {
  const [twitch, kick, youtube] = await Promise.all([
    isTwitchLive(),
    isKickLive(),
    isYoutubeLive(),
  ]);

  // Se mais de uma plataforma aparecer ao vivo ao mesmo tempo, prioridade:
  // twitch > kick > youtube (ajuste a ordem se preferir outra)
  let platform = null;
  if (twitch) platform = 'twitch';
  else if (kick) platform = 'kick';
  else if (youtube) platform = 'youtube';

  const state = readState();
  if (state.live.platform !== platform) {
    state.live = { platform, updatedAt: new Date().toISOString() };
    writeState(state);
    console.log('Plataforma ao vivo agora:', platform);
  }
}

const CHECK_INTERVAL = Number(process.env.LIVE_CHECK_INTERVAL_MS) || 45000;
setInterval(checkWhoIsLive, CHECK_INTERVAL);
checkWhoIsLive();

app.listen(PORT, () => {
  console.log(`Overlay hub rodando em http://0.0.0.0:${PORT}`);
  console.log(`Overlay (adicionar no OBS):  http://SEU_IP:${PORT}/overlay`);
  console.log(`Painel de controle:          http://SEU_IP:${PORT}/control?key=${CONTROL_KEY}`);
});
