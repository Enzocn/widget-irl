require('dotenv').config();
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 8090;
const CONTROL_KEY = process.env.CONTROL_KEY || 'troque-isso';
const MAPTILER_KEY = process.env.MAPTILER_KEY || '';
const ORS_KEY = process.env.ORS_KEY || '';
const STATE_PATH = path.join(__dirname, 'state.json');
const GPS_DEVICES_PATH = path.join(__dirname, 'gps-devices.json');
const GPS_ROUTE_PATH = path.join(__dirname, 'gps-route.json');

const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: '/ws' });
function broadcast(msg) {
  const data = JSON.stringify(msg);
  wss.clients.forEach((c) => { if (c.readyState === WebSocket.OPEN) c.send(data); });
}

// ---------- Estado do overlay (persistido em disco) ----------
function readState() {
  return JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
}
function writeState(state) {
  fs.writeFileSync(STATE_PATH, JSON.stringify(state, null, 2));
}

// Mescla parcial (deep merge de 1 nivel, que e o suficiente para nosso schema)
function mergeState(current, patch) {
  const next = { ...current };
  for (const key of Object.keys(patch)) {
    if (
      typeof patch[key] === 'object' &&
      patch[key] !== null &&
      !Array.isArray(patch[key])
    ) {
      next[key] = { ...current[key], ...patch[key] };
    } else {
      next[key] = patch[key];
    }
  }
  return next;
}

// ---------- Rotas publicas (o overlay le sem chave) ----------
app.get('/api/state', (req, res) => {
  res.json(readState());
});

// Clima: buscado aqui no servidor, a chave nunca aparece no navegador nem no repositorio
let weatherCache = { data: null, fetchedAt: 0, lat: null, lon: null };
app.get('/api/weather', async (req, res) => {
  try {
    const key = process.env.OPENWEATHER_KEY;
    if (!key) return res.json({ error: 'sem chave configurada' });

    const now = Date.now();
    // Usa a posicao GPS mais recente (de qualquer celular). Se nenhum celular
    // ja mandou posicao nesta execucao do servidor, cai pro ultimo lugar
    // salvo em disco; se nunca teve nenhuma, usa a cidade fixa do .env.
    const useGps = !!lastGpsPosition;
    const lat = useGps ? lastGpsPosition.lat : null;
    const lon = useGps ? lastGpsPosition.lon : null;

    const samePlace =
      useGps &&
      weatherCache.lat != null &&
      Math.abs(weatherCache.lat - lat) < 0.05 &&
      Math.abs(weatherCache.lon - lon) < 0.05;
    const cacheValid = weatherCache.data && now - weatherCache.fetchedAt < 5 * 60 * 1000;

    if (cacheValid && ((useGps && samePlace) || (!useGps && weatherCache.lat === null))) {
      return res.json(weatherCache.data);
    }

    const city = process.env.WEATHER_CITY || 'São Paulo';
    const url = useGps
      ? `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${key}&units=metric&lang=pt_br`
      : `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${key}&units=metric&lang=pt_br`;

    const resp = await fetch(url);
    const data = await resp.json();
    if (!data.main || !data.weather) return res.json({ error: 'erro na resposta do clima' });

    const result = { temp: Math.round(data.main.temp), icon: data.weather[0].icon };
    weatherCache = { data: result, fetchedAt: now, lat, lon };
    res.json(result);
  } catch (e) {
    console.error('Erro buscando clima:', e.message);
    res.json({ error: 'erro buscando clima' });
  }
});

app.use(express.static(path.join(__dirname, 'public')));

app.get('/overlay', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'overlay.html'));
});

// ---------- Rotas protegidas (painel de controle) ----------
function requireKey(req, res, next) {
  const key = req.query.key || req.headers['x-control-key'];
  if (key !== CONTROL_KEY) {
    return res.status(401).json({ error: 'chave invalida' });
  }
  next();
}

app.get('/control', requireKey, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'control.html'));
});

app.post('/api/state', requireKey, (req, res) => {
  const current = readState();
  const next = mergeState(current, req.body || {});
  writeState(next);
  res.json(next);
});

// =====================================================================
// GPS: celulares (1 ou mais) com marcador no mapa + rota ponto a ponto
// A rota e opcional - funciona normalmente so com posicao de celular(es)
// =====================================================================

let gpsDevices = {}; // device_id -> { label, color }
if (fs.existsSync(GPS_DEVICES_PATH)) gpsDevices = JSON.parse(fs.readFileSync(GPS_DEVICES_PATH, 'utf8'));
function saveGpsDevices() { fs.writeFileSync(GPS_DEVICES_PATH, JSON.stringify(gpsDevices, null, 2)); }

const GPS_LASTPOS_PATH = path.join(__dirname, 'gps-last-position.json');
let lastGpsPosition = null; // {lat, lon, ts} - usado pelo clima quando ha GPS
if (fs.existsSync(GPS_LASTPOS_PATH)) lastGpsPosition = JSON.parse(fs.readFileSync(GPS_LASTPOS_PATH, 'utf8'));

let activeRoute = null; // null = sem rota (funciona normalmente)
if (fs.existsSync(GPS_ROUTE_PATH)) activeRoute = JSON.parse(fs.readFileSync(GPS_ROUTE_PATH, 'utf8'));

const gpsPositions = {}; // device_id -> {lat, lon, ts, speed, accuracy}
const gpsTrails = {};    // device_id -> [{lat, lon, ts}, ...]
const TRAIL_MAX = 300;

const GPS_COLORS = ['#ff4d4d', '#4da6ff', '#4dff88', '#ffd24d', '#c04dff', '#ff914d'];
function colorForDevice(id) {
  if (gpsDevices[id]?.color) return gpsDevices[id].color;
  const idx = Object.keys(gpsDevices).indexOf(id);
  return GPS_COLORS[(idx >= 0 ? idx : Object.keys(gpsDevices).length) % GPS_COLORS.length];
}

app.get('/api/gps/config', (req, res) => {
  res.json({ maptilerKey: MAPTILER_KEY });
});

// Compativel com o "Custom URL" do app GPSLogger (Android):
// http://SEU_IP:8090/api/gps/position?device_id=enzo&lat=%LAT&lon=%LON&speed=%SPD&acc=%ACC&ts=%TIMESTAMP
app.get('/api/gps/position', handleGpsPosition);
app.post('/api/gps/position', handleGpsPosition);

function handleGpsPosition(req, res) {
  const q = { ...req.query, ...req.body };
  const device_id = String(q.device_id || 'default');
  const lat = parseFloat(q.lat);
  const lon = parseFloat(q.lon);
  if (Number.isNaN(lat) || Number.isNaN(lon)) {
    return res.status(400).json({ error: 'lat/lon invalidos' });
  }

  const point = {
    lat, lon,
    speed: q.speed !== undefined ? parseFloat(q.speed) : null,
    accuracy: q.acc !== undefined ? parseFloat(q.acc) : null,
    ts: q.ts ? (new Date(q.ts).getTime() || Date.now()) : Date.now()
  };

  gpsPositions[device_id] = point;
  if (!gpsDevices[device_id]) { gpsDevices[device_id] = { label: device_id }; saveGpsDevices(); }
  if (!gpsTrails[device_id]) gpsTrails[device_id] = [];
  gpsTrails[device_id].push(point);
  if (gpsTrails[device_id].length > TRAIL_MAX) gpsTrails[device_id].shift();

  lastGpsPosition = { lat: point.lat, lon: point.lon, ts: point.ts };
  fs.writeFileSync(GPS_LASTPOS_PATH, JSON.stringify(lastGpsPosition, null, 2));

  broadcast({
    type: 'gps-position',
    device_id,
    point,
    color: colorForDevice(device_id),
    label: gpsDevices[device_id].label
  });

  res.json({ ok: true });
}

app.get('/api/gps/state', (req, res) => {
  res.json({
    devices: Object.fromEntries(Object.keys(gpsPositions).map((id) => [id, {
      label: gpsDevices[id]?.label || id,
      color: colorForDevice(id),
      point: gpsPositions[id],
      trail: gpsTrails[id] || []
    }])),
    route: activeRoute
  });
});

app.post('/api/gps/devices/:id/label', requireKey, (req, res) => {
  const id = req.params.id;
  const { label, color } = req.body;
  gpsDevices[id] = {
    ...(gpsDevices[id] || {}),
    ...(label ? { label } : {}),
    ...(color ? { color } : {})
  };
  saveGpsDevices();
  broadcast({ type: 'gps-device', device_id: id, label: gpsDevices[id].label, color: colorForDevice(id) });
  res.json({ ok: true, device: gpsDevices[id] });
});

// Rota ponto a ponto (opcional). Funciona normalmente sem nenhuma rota ativa.
app.post('/api/gps/route', requireKey, async (req, res) => {
  try {
    const { name, points, profile } = req.body; // points: [{lat,lon}, ...] em ordem, min 2
    if (!ORS_KEY) return res.status(400).json({ error: 'ORS_KEY nao configurada no .env' });
    if (!points || points.length < 2) return res.status(400).json({ error: 'Precisa de ao menos 2 pontos' });

    const coordinates = points.map((p) => [p.lon, p.lat]);
    const r = await fetch(`https://api.openrouteservice.org/v2/directions/${profile || 'driving-car'}/geojson`, {
      method: 'POST',
      headers: { Authorization: ORS_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({ coordinates })
    });
    const geojson = await r.json();
    if (!r.ok) return res.status(r.status).json({ error: 'Erro na OpenRouteService', details: geojson });

    activeRoute = { name: name || 'Rota', geojson, createdAt: Date.now() };
    fs.writeFileSync(GPS_ROUTE_PATH, JSON.stringify(activeRoute, null, 2));
    broadcast({ type: 'gps-route', route: activeRoute });
    res.json({ ok: true, route: activeRoute });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.delete('/api/gps/route', requireKey, (req, res) => {
  activeRoute = null;
  if (fs.existsSync(GPS_ROUTE_PATH)) fs.unlinkSync(GPS_ROUTE_PATH);
  broadcast({ type: 'gps-route', route: null });
  res.json({ ok: true });
});

// ---------- Checagem de "quem esta ao vivo" ----------
let twitchToken = null;
let twitchTokenExpiry = 0;

async function getTwitchToken() {
  if (twitchToken && Date.now() < twitchTokenExpiry) return twitchToken;
  if (!process.env.TWITCH_CLIENT_ID || !process.env.TWITCH_CLIENT_SECRET) return null;
  const resp = await fetch(
    `https://id.twitch.tv/oauth2/token?client_id=${process.env.TWITCH_CLIENT_ID}&client_secret=${process.env.TWITCH_CLIENT_SECRET}&grant_type=client_credentials`,
    { method: 'POST' }
  );
  const data = await resp.json();
  if (!data.access_token) return null;
  twitchToken = data.access_token;
  twitchTokenExpiry = Date.now() + (data.expires_in - 60) * 1000;
  return twitchToken;
}

async function isTwitchLive() {
  try {
    const token = await getTwitchToken();
    if (!token) return false;
    const resp = await fetch(
      `https://api.twitch.tv/helix/streams?user_login=${process.env.TWITCH_USER_LOGIN}`,
      {
        headers: {
          'Client-Id': process.env.TWITCH_CLIENT_ID,
          Authorization: `Bearer ${token}`,
        },
      }
    );
    const data = await resp.json();
    return Array.isArray(data.data) && data.data.length > 0;
  } catch (e) {
    console.error('Erro checando Twitch:', e.message);
    return false;
  }
}

async function isKickLive() {
  try {
    if (!process.env.KICK_CHANNEL) return false;
    const resp = await fetch(
      `https://kick.com/api/v2/channels/${process.env.KICK_CHANNEL}`,
      { headers: { 'User-Agent': 'Mozilla/5.0' } }
    );
    if (!resp.ok) return false;
    const data = await resp.json();
    return !!data.livestream;
  } catch (e) {
    console.error('Erro checando Kick (a Cloudflare da Kick pode bloquear chamadas de servidor):', e.message);
    return false;
  }
}

async function isYoutubeLive() {
  try {
    if (!process.env.YOUTUBE_API_KEY || !process.env.YOUTUBE_CHANNEL_ID) return false;
    const resp = await fetch(
      `https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=${process.env.YOUTUBE_CHANNEL_ID}&eventType=live&type=video&key=${process.env.YOUTUBE_API_KEY}`
    );
    const data = await resp.json();
    return Array.isArray(data.items) && data.items.length > 0;
  } catch (e) {
    console.error('Erro checando YouTube:', e.message);
    return false;
  }
}

async function checkWhoIsLive() {
  const [twitch, kick, youtube] = await Promise.all([
    isTwitchLive(),
    isKickLive(),
    isYoutubeLive(),
  ]);

  // Se mais de uma plataforma aparecer ao vivo ao mesmo tempo, prioridade:
  // twitch > kick > youtube (ajuste a ordem se preferir outra)
  let platform = null;
  if (twitch) platform = 'twitch';
  else if (kick) platform = 'kick';
  else if (youtube) platform = 'youtube';

  const state = readState();
  if (state.live.platform !== platform) {
    state.live = { platform, updatedAt: new Date().toISOString() };
    writeState(state);
    console.log('Plataforma ao vivo agora:', platform);
  }
}

const CHECK_INTERVAL = Number(process.env.LIVE_CHECK_INTERVAL_MS) || 45000;
setInterval(checkWhoIsLive, CHECK_INTERVAL);
checkWhoIsLive();

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Overlay hub rodando em http://0.0.0.0:${PORT}`);
  console.log(`Overlay (adicionar no OBS):  http://SEU_IP:${PORT}/overlay`);
  console.log(`Painel de controle:          http://SEU_IP:${PORT}/control?key=${CONTROL_KEY}`);
});
