# Overlay Hub — enzocn_

Junta logo, QR code (imagem fixa), GPS (celular(es) com marcador + rota
opcional) e widget de clima/data/hora num único overlay, controlado por uma
URL de painel com toggles. Também detecta sozinho em qual plataforma (Twitch,
Kick ou YouTube) você está ao vivo e mostra só o selo daquela plataforma.

**Removido nesta versão:** chat e alerta (Streamlabs). O QR code continua,
mas agora é uma **imagem fixa** (`public/qrcode.png`) em vez de gerado a
partir de um link dinâmico — pra trocar, é só substituir esse arquivo.

Por que não dá pra fazer isso 100% no GitHub Pages: GitHub Pages só serve
arquivos estáticos, e aqui a gente precisa de um "estado" que o painel de
controle escreve e o overlay lê em tempo real — isso exige um servidor rodando.
Como você já tem o `cn-server` (ou a notebook Ryzen, que já roda Node.js pro
obs-web), a solução mais simples é rodar este mesmo tipo de serviço lá, na
mesma máquina.

## 1. Instalar

Copie a pasta `overlay-hub` para o servidor (pode ser via `scp`, `git clone` de
um repositório privado seu, ou USB). Depois:

```bash
cd overlay-hub
npm install
cp .env.example .env
nano .env   # preencha CONTROL_KEY, MAPTILER_KEY, ORS_KEY e (opcional) Twitch/YouTube
npm start
```

Por padrão sobe em `http://0.0.0.0:8090`.

## 2. Adicionar no OBS

- **Fonte de navegador (Browser Source):** `http://IP_DO_SERVIDOR:8090/overlay`
  - Marque "Atualizar navegador quando a cena ficar ativa" se quiser, mas não
    é obrigatório: o overlay já busca o estado sozinho a cada 3 segundos.
  - Largura/altura: use o tamanho da sua tela de transmissão (ex: 1920x1080).

## 3. Painel de controle

Abra no celular ou no navegador do PC:

```
http://IP_DO_SERVIDOR:8090/control?key=SUA_CONTROL_KEY
```

Ali dá pra, em tempo real:
- Ligar/desligar e trocar o lado (esquerda/direita) da logo, do GPS, do widget
  de clima/data/hora e do contador de plataforma
- Ligar/desligar clima, data e hora separadamente
- Criar/ativar uma rota ponto a ponto pro GPS (ou deixar sem nenhuma — o mapa
  funciona normalmente só com a posição do(s) celular(es))
- Dar um nome de exibição pra cada celular que estiver mandando posição

Guarde essa URL com a chave como se fosse uma senha — quem tiver o link
consegue mexer no seu overlay ao vivo. Se quiser mais segurança, dá pra
colocar atrás de autenticação básica do nginx, já que você já usa nginx no
`cn-server`.

## 4. Contador de plataforma (Twitch / Kick / YouTube)

O servidor confere de tempos em tempos (padrão: a cada 45s, ajustável em
`LIVE_CHECK_INTERVAL_MS`) se você está ao vivo em cada plataforma:

- **Twitch:** precisa de `TWITCH_CLIENT_ID` e `TWITCH_CLIENT_SECRET` (crie um
  app grátis em https://dev.twitch.tv/console/apps) e `TWITCH_USER_LOGIN=enzocn_`.
- **Kick:** usa a API pública não-oficial da Kick, só precisa do
  `KICK_CHANNEL=enzocn_`. Como não é uma API oficial, a Kick pode bloquear
  requisições de servidor via Cloudflare de vez em quando — se isso acontecer
  bastante, me avisa que dá pra trocar por outra abordagem (ex: webhook do
  próprio painel quando você entra ao vivo).
- **YouTube:** opcional, só se você também transmitir por lá. Precisa de
  `YOUTUBE_API_KEY` e `YOUTUBE_CHANNEL_ID`.

Se mais de uma plataforma estiver ao vivo ao mesmo tempo, a prioridade no
código é Twitch > Kick > YouTube — dá pra mudar isso em `checkWhoIsLive()` no
`server.js`.

## 5. Rodando sempre ligado (systemd)

Já que você já usa systemd pro NOALBS, o mesmo padrão serve aqui:

```ini
# /etc/systemd/system/overlay-hub.service
[Unit]
Description=Overlay Hub
After=network.target

[Service]
WorkingDirectory=/home/enzo/overlay-hub
ExecStart=/usr/bin/node server.js
Restart=always
User=enzo

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now overlay-hub
```

## 6. QR Code (imagem fixa)

Diferente da versão antiga (que gerava o QR a partir de um link dinâmico do
LivePix), agora o QR é só uma imagem estática servida direto do servidor:
`public/qrcode.png`. Pra trocar o QR (ex: mudou de plataforma de doação),
basta substituir esse arquivo por outra imagem PNG com o mesmo nome — não
precisa reiniciar o servidor, só atualizar a página do overlay no OBS.

No painel de controle dá pra ligar/desligar, escolher o lado (esquerda ou
direita), e ativar o ciclo automático (aparece 10s, some por 1 minuto) —
igual funcionava antes.

## 7. GPS — celular(es) + rota opcional

O widget de GPS aparece como uma caixinha de mapa (satélite) no canto
inferior esquerdo ou direito, escolhido no painel de controle. Funciona
com **1 ou mais celulares** — cada um manda a própria posição com um
`device_id` diferente — e a **rota é sempre opcional**: sem nenhuma
ativada, o mapa mostra só o(s) marcador(es) e a trilha percorrida.

### Configurar cada celular

Recomendo o app **GPSLogger** (Android, grátis, sem conta, roda em segundo
plano com boa economia de bateria):

1. Instale o GPSLogger.
2. Em **Log destinations**, ative **Custom URL**.
3. URL (troque `enzo` pelo nome de cada celular, e o IP pelo do seu servidor):

```
http://IP_DO_SERVIDOR:8090/api/gps/position?device_id=enzo&lat=%LAT&lon=%LON&speed=%SPD&acc=%ACC&ts=%TIMESTAMP
```

4. Method: `GET`. Ajuste o intervalo de log em **Performance/logging** (ex: 3-5s).
5. Repita em cada celular trocando só o `device_id`.

Cada `device_id` novo aparece automaticamente na lista de "Celulares
conectados" no painel de controle, onde dá pra dar um nome de exibição.

### Criar uma rota (opcional)

No painel de controle, seção **GPS — rota e celulares**: clique no mapa
marcando os pontos na ordem (origem → paradas → destino), escolha o meio
(carro/bike/a pé) e clique em **Calcular e ativar**. A rota calculada
(seguindo ruas de verdade, via OpenRouteService) aparece na hora no overlay
como uma linha tracejada. **Remover rota ativa** tira ela — o overlay volta
a mostrar só os marcadores dos celulares, normalmente.

### Chaves necessárias

- `MAPTILER_KEY` — tiles de satélite, grátis, sem cartão (cloud.maptiler.com)
- `ORS_KEY` — cálculo de rota, grátis, sem cartão (openrouteservice.org)

## 8. Sobre o GitHub

Se ainda assim quiser manter o código no GitHub (bom para versionar e não
perder nada), crie um repositório **privado** e:
- **Não** commite o arquivo `.env` (ele tem suas chaves) — já deixei um
  `.gitignore` sugerido abaixo.
- O `state.json`, `gps-devices.json`, `gps-route.json` e
  `gps-last-position.json` também não precisam ir pro Git, são
  gerados/atualizados pelo próprio servidor.

```
.env
state.json
gps-devices.json
gps-route.json
gps-last-position.json
node_modules/
```

O deploy em si continua sendo feito no seu servidor (Git só guarda o código-fonte).
