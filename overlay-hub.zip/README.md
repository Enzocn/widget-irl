# Overlay Hub — enzocn_

Junta logo, QR do LivePix, chat multiplataforma, alerta e widget de clima/data/hora
num único overlay, controlado por uma URL de painel com toggles. Também detecta
sozinho em qual plataforma (Twitch, Kick ou YouTube) você está ao vivo e mostra
só o selo daquela plataforma.

Por que não dá pra fazer isso 100% no GitHub Pages: GitHub Pages só serve
arquivos estáticos, e aqui a gente precisa de um "estado" que o painel de
controle escreve e o overlay lê em tempo real — isso exige um servidor rodando.
Como você já tem o `cn-server` (ou a notebook Ryzen, que já roda Node.js pro
obs-web), a solução mais simples é rodar este mesmo tipo de serviço lá, na
mesma máquina.

## 1. Instalar

Copie a pasta `overlay-hub` para o servidor (pode ser via `scp`, `git clone` de
um repositório privado seu, ou USB). Depois:

```bash
cd overlay-hub
npm install
cp .env.example .env
nano .env   # preencha CONTROL_KEY e (opcional) as chaves de Twitch/YouTube
npm start
```

Por padrão sobe em `http://0.0.0.0:8090`.

## 2. Adicionar no OBS

- **Fonte de navegador (Browser Source):** `http://IP_DO_SERVIDOR:8090/overlay`
  - Marque "Atualizar navegador quando a cena ficar ativa" se quiser, mas não
    é obrigatório: o overlay já busca o estado sozinho a cada 3 segundos.
  - Largura/altura: use o tamanho da sua tela de transmissão (ex: 1920x1080).

## 3. Painel de controle

Abra no celular ou no navegador do PC:

```
http://IP_DO_SERVIDOR:8090/control?key=SUA_CONTROL_KEY
```

Ali dá pra, em tempo real:
- Ligar/desligar e trocar o lado (esquerda/direita) da logo, do QR do LivePix,
  do chat, do widget de clima/data/hora e do contador de plataforma
- Ativar o ciclo automático do LivePix (aparece 10s, some por 1 minuto)
- Ligar/desligar clima, data e hora separadamente
- Ligar/desligar o alerta (ele fica sempre fixo, centralizado, a 1/4 do topo)

Guarde essa URL com a chave como se fosse uma senha — quem tiver o link
consegue mexer no seu overlay ao vivo. Se quiser mais segurança, dá pra
colocar atrás de autenticação básica do nginx, já que você já usa nginx no
`cn-server`.

## 4. Contador de plataforma (Twitch / Kick / YouTube)

O servidor confere de tempos em tempos (padrão: a cada 45s, ajustável em
`LIVE_CHECK_INTERVAL_MS`) se você está ao vivo em cada plataforma:

- **Twitch:** precisa de `TWITCH_CLIENT_ID` e `TWITCH_CLIENT_SECRET` (crie um
  app grátis em https://dev.twitch.tv/console/apps) e `TWITCH_USER_LOGIN=enzocn_`.
- **Kick:** usa a API pública não-oficial da Kick, só precisa do
  `KICK_CHANNEL=enzocn_`. Como não é uma API oficial, a Kick pode bloquear
  requisições de servidor via Cloudflare de vez em quando — se isso acontecer
  bastante, me avisa que dá pra trocar por outra abordagem (ex: webhook do
  próprio painel quando você entra ao vivo).
- **YouTube:** opcional, só se você também transmitir por lá. Precisa de
  `YOUTUBE_API_KEY` e `YOUTUBE_CHANNEL_ID`.

Se mais de uma plataforma estiver ao vivo ao mesmo tempo, a prioridade no
código é Twitch > Kick > YouTube — dá pra mudar isso em `checkWhoIsLive()` no
`server.js`.

## 5. Rodando sempre ligado (systemd)

Já que você já usa systemd pro NOALBS, o mesmo padrão serve aqui:

```ini
# /etc/systemd/system/overlay-hub.service
[Unit]
Description=Overlay Hub
After=network.target

[Service]
WorkingDirectory=/home/enzo/overlay-hub
ExecStart=/usr/bin/node server.js
Restart=always
User=enzo

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now overlay-hub
```

## 6. Sobre o GPS

Como você comentou que desativou o GPS por enquanto, não incluí nada de
localização em tempo real aqui — o widget de clima usa a cidade fixa
(São Paulo). Quando você quiser reativar (RealtimeIRL, por exemplo), dá pra
plugar como mais um item dentro do mesmo `overlay.html`.

## 7. Sobre o GitHub

Se ainda assim quiser manter o código no GitHub (bom para versionar e não
perder nada), crie um repositório **privado** e:
- **Não** commite o arquivo `.env` (ele tem suas chaves) — já deixei um
  `.gitignore` sugerido abaixo.
- O `state.json` também não precisa ir pro Git, ele é gerado/atualizado pelo
  próprio servidor.

```
.env
state.json
node_modules/
```

O deploy em si continua sendo feito no seu servidor (Git só guarda o código-fonte).
