require('dotenv').config();
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');
const { spawn } = require('child_process');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true })); // o callback on_publish do nginx manda form-urlencoded

const PORT = process.env.PORT || 8090;
const CONTROL_KEY = process.env.CONTROL_KEY || 'troque-isso';
const MAPTILER_KEY = process.env.MAPTILER_KEY || '';
const ORS_KEY = process.env.ORS_KEY || '';
const STATE_PATH = path.join(__dirname, 'state.json');
const GPS_DEVICES_PATH = path.join(__dirname, 'gps-devices.json');
const GPS_ROUTE_PATH = path.join(__dirname, 'gps-route.json');

const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: '/ws' });
function broadcast(msg) {
  const data = JSON.stringify(msg);
  wss.clients.forEach((c) => { if (c.readyState === WebSocket.OPEN) c.send(data); });
}

// ---------- Estado do overlay (persistido em disco) ----------
function readState() {
  return JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
}
function writeState(state) {
  fs.writeFileSync(STATE_PATH, JSON.stringify(state, null, 2));
}

// Mescla parcial (deep merge de 1 nivel, que e o suficiente para nosso schema)
function mergeState(current, patch) {
  const next = { ...current };
  for (const key of Object.keys(patch)) {
    if (
      typeof patch[key] === 'object' &&
      patch[key] !== null &&
      !Array.isArray(patch[key])
    ) {
      next[key] = { ...current[key], ...patch[key] };
    } else {
      next[key] = patch[key];
    }
  }
  return next;
}

// ---------- Rotas publicas (o overlay le sem chave) ----------
app.get('/api/state', (req, res) => {
  res.json({
    ...readState(),
    currentScene: currentSceneName,
    gpsActiveDevices: Object.keys(gpsPositions).length,
  });
});

// Clima: buscado aqui no servidor, a chave nunca aparece no navegador nem no repositorio
let weatherCache = { data: null, fetchedAt: 0, lat: null, lon: null };
app.get('/api/weather', async (req, res) => {
  try {
    const key = process.env.OPENWEATHER_KEY;
    if (!key) return res.json({ error: 'sem chave configurada' });

    const now = Date.now();
    const useGps = !!lastGpsPosition;
    const lat = useGps ? lastGpsPosition.lat : null;
    const lon = useGps ? lastGpsPosition.lon : null;

    const samePlace =
      useGps &&
      weatherCache.lat != null &&
      Math.abs(weatherCache.lat - lat) < 0.05 &&
      Math.abs(weatherCache.lon - lon) < 0.05;
    const cacheValid = weatherCache.data && now - weatherCache.fetchedAt < 5 * 60 * 1000;

    if (cacheValid && ((useGps && samePlace) || (!useGps && weatherCache.lat === null))) {
      return res.json(weatherCache.data);
    }

    const city = process.env.WEATHER_CITY || 'São Paulo';
    const url = useGps
      ? `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${key}&units=metric&lang=pt_br`
      : `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${key}&units=metric&lang=pt_br`;

    const resp = await fetch(url);
    const data = await resp.json();
    if (!data.main || !data.weather) return res.json({ error: 'erro na resposta do clima' });

    const result = { temp: Math.round(data.main.temp), icon: data.weather[0].icon };
    weatherCache = { data: result, fetchedAt: now, lat, lon };
    res.json(result);
  } catch (e) {
    console.error('Erro buscando clima:', e.message);
    res.json({ error: 'erro buscando clima' });
  }
});

app.use(express.static(path.join(__dirname, 'public')));

app.get('/overlay', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'overlay.html'));
});

// ---------- Rotas protegidas (painel de controle) ----------
function requireKey(req, res, next) {
  const key = req.query.key || req.headers['x-control-key'];
  if (key !== CONTROL_KEY) {
    return res.status(401).json({ error: 'chave invalida' });
  }
  next();
}

app.get('/control', requireKey, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'control.html'));
});

app.post('/api/state', requireKey, (req, res) => {
  const current = readState();
  const next = mergeState(current, req.body || {});
  writeState(next);
  res.json(next);
});

// =====================================================================
// GPS: celulares (1 ou mais) com marcador no mapa + rota ponto a ponto
// A rota e opcional - funciona normalmente so com posicao de celular(es)
// =====================================================================

let gpsDevices = {}; // device_id -> { label, color }
if (fs.existsSync(GPS_DEVICES_PATH)) gpsDevices = JSON.parse(fs.readFileSync(GPS_DEVICES_PATH, 'utf8'));
function saveGpsDevices() { fs.writeFileSync(GPS_DEVICES_PATH, JSON.stringify(gpsDevices, null, 2)); }

const GPS_LASTPOS_PATH = path.join(__dirname, 'gps-last-position.json');
let lastGpsPosition = null; // {lat, lon, ts} - usado pelo clima quando ha GPS
if (fs.existsSync(GPS_LASTPOS_PATH)) lastGpsPosition = JSON.parse(fs.readFileSync(GPS_LASTPOS_PATH, 'utf8'));

let activeRoute = null; // null = sem rota (funciona normalmente)
if (fs.existsSync(GPS_ROUTE_PATH)) activeRoute = JSON.parse(fs.readFileSync(GPS_ROUTE_PATH, 'utf8'));

const gpsPositions = {}; // device_id -> {lat, lon, ts, speed, accuracy}
const gpsTrails = {};    // device_id -> [{lat, lon, ts}, ...]
const TRAIL_MAX = 300;

const GPS_COLORS = ['#ff4d4d', '#4da6ff', '#4dff88', '#ffd24d', '#c04dff', '#ff914d'];
function colorForDevice(id) {
  if (gpsDevices[id]?.color) return gpsDevices[id].color;
  const idx = Object.keys(gpsDevices).indexOf(id);
  return GPS_COLORS[(idx >= 0 ? idx : Object.keys(gpsDevices).length) % GPS_COLORS.length];
}

app.get('/api/gps/config', (req, res) => {
  res.json({ maptilerKey: MAPTILER_KEY });
});

// Compativel com o "Custom URL" do app GPSLogger (Android):
// http://SEU_IP:8090/api/gps/position?device_id=enzo&lat=%LAT&lon=%LON&speed=%SPD&acc=%ACC&ts=%TIMESTAMP
app.get('/api/gps/position', handleGpsPosition);
app.post('/api/gps/position', handleGpsPosition);

function handleGpsPosition(req, res) {
  const q = { ...req.query, ...req.body };
  const device_id = String(q.device_id || 'default');
  const lat = parseFloat(q.lat);
  const lon = parseFloat(q.lon);
  if (Number.isNaN(lat) || Number.isNaN(lon)) {
    return res.status(400).json({ error: 'lat/lon invalidos' });
  }

  const point = {
    lat, lon,
    speed: q.speed !== undefined ? parseFloat(q.speed) : null,
    accuracy: q.acc !== undefined ? parseFloat(q.acc) : null,
    ts: q.ts ? (new Date(q.ts).getTime() || Date.now()) : Date.now()
  };

  gpsPositions[device_id] = point;
  if (!gpsDevices[device_id]) { gpsDevices[device_id] = { label: device_id }; saveGpsDevices(); }
  if (!gpsTrails[device_id]) gpsTrails[device_id] = [];
  gpsTrails[device_id].push(point);
  if (gpsTrails[device_id].length > TRAIL_MAX) gpsTrails[device_id].shift();

  lastGpsPosition = { lat: point.lat, lon: point.lon, ts: point.ts };
  fs.writeFileSync(GPS_LASTPOS_PATH, JSON.stringify(lastGpsPosition, null, 2));

  broadcast({
    type: 'gps-position',
    device_id,
    point,
    color: colorForDevice(device_id),
    label: gpsDevices[device_id].label
  });

  res.json({ ok: true });
}

app.get('/api/gps/state', (req, res) => {
  res.json({
    devices: Object.fromEntries(Object.keys(gpsPositions).map((id) => [id, {
      label: gpsDevices[id]?.label || id,
      color: colorForDevice(id),
      point: gpsPositions[id],
      trail: gpsTrails[id] || []
    }])),
    route: activeRoute
  });
});

app.post('/api/gps/devices/:id/label', requireKey, (req, res) => {
  const id = req.params.id;
  const { label, color } = req.body;
  gpsDevices[id] = {
    ...(gpsDevices[id] || {}),
    ...(label ? { label } : {}),
    ...(color ? { color } : {})
  };
  saveGpsDevices();
  broadcast({ type: 'gps-device', device_id: id, label: gpsDevices[id].label, color: colorForDevice(id) });
  res.json({ ok: true, device: gpsDevices[id] });
});

// Rota ponto a ponto (opcional). Funciona normalmente sem nenhuma rota ativa.
app.post('/api/gps/route', requireKey, async (req, res) => {
  try {
    const { name, points, profile } = req.body; // points: [{lat,lon}, ...] em ordem, min 2
    if (!ORS_KEY) return res.status(400).json({ error: 'ORS_KEY nao configurada no .env' });
    if (!points || points.length < 2) return res.status(400).json({ error: 'Precisa de ao menos 2 pontos' });

    const coordinates = points.map((p) => [p.lon, p.lat]);
    const r = await fetch(`https://api.openrouteservice.org/v2/directions/${profile || 'driving-car'}/geojson`, {
      method: 'POST',
      headers: { Authorization: ORS_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({ coordinates })
    });
    const geojson = await r.json();
    if (!r.ok) return res.status(r.status).json({ error: 'Erro na OpenRouteService', details: geojson });

    activeRoute = { name: name || 'Rota', geojson, createdAt: Date.now() };
    fs.writeFileSync(GPS_ROUTE_PATH, JSON.stringify(activeRoute, null, 2));
    broadcast({ type: 'gps-route', route: activeRoute });
    res.json({ ok: true, route: activeRoute });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.delete('/api/gps/route', requireKey, (req, res) => {
  activeRoute = null;
  if (fs.existsSync(GPS_ROUTE_PATH)) fs.unlinkSync(GPS_ROUTE_PATH);
  broadcast({ type: 'gps-route', route: null });
  res.json({ ok: true });
});

// =====================================================================
// Multistream: OBS manda 1 unico RTMP pro nginx, e cada plataforma
// (Twitch/Kick/YouTube) e um processo ffmpeg independente, controlavel
// separadamente pelo painel - sem precisar mexer no OBS.
// =====================================================================
const MULTISTREAM_STATE_PATH = path.join(__dirname, 'multistream-state.json');

// Preferencia de cada plataforma: liga automaticamente quando o OBS comeca a publicar
let msPrefs = { twitch: true, kick: true, youtube: false };
if (fs.existsSync(MULTISTREAM_STATE_PATH)) {
  msPrefs = { ...msPrefs, ...JSON.parse(fs.readFileSync(MULTISTREAM_STATE_PATH, 'utf8')) };
}
function saveMsPrefs() { fs.writeFileSync(MULTISTREAM_STATE_PATH, JSON.stringify(msPrefs, null, 2)); }

const msProcesses = {}; // platform -> { proc, running, intentionalStop }
let msLive = false;
let msStreamName = null;

const MS_DESTINATIONS = {
  twitch: () => (process.env.TWITCH_STREAM_KEY ? `rtmp://live.twitch.tv/app/${process.env.TWITCH_STREAM_KEY}` : null),
  kick: () => process.env.KICK_RTMPS_URL || null,
  youtube: () => (process.env.YOUTUBE_STREAM_KEY ? `rtmp://a.rtmp.youtube.com/live2/${process.env.YOUTUBE_STREAM_KEY}` : null),
};

function msSourceUrl() {
  return `rtmp://127.0.0.1:1936/live/${msStreamName}`;
}

function startPush(platform) {
  if (!msLive || !msStreamName) return;
  const dest = MS_DESTINATIONS[platform] && MS_DESTINATIONS[platform]();
  if (!dest) { console.error(`Multistream: sem destino configurado pra ${platform} (falta chave no .env)`); return; }
  if (msProcesses[platform] && msProcesses[platform].running) return; // ja rodando

  const logPath = path.join(__dirname, `multistream-${platform}.log`);
  const logStream = fs.createWriteStream(logPath, { flags: 'a' });
  const proc = spawn('/usr/bin/ffmpeg', ['-i', msSourceUrl(), '-c', 'copy', '-f', 'flv', dest]);
  proc.stderr.pipe(logStream);
  msProcesses[platform] = { proc, running: true, intentionalStop: false };
  broadcast({ type: 'ms-status', platform, running: true });
  updateLiveFromMultistream();
  console.log(`Multistream: iniciou push pra ${platform}`);

  proc.on('exit', (code) => {
    const entry = msProcesses[platform];
    const wasIntentional = entry && entry.intentionalStop;
    if (entry) entry.running = false;
    console.log(`Multistream: ${platform} encerrou (codigo ${code}, intencional: ${!!wasIntentional})`);
    broadcast({ type: 'ms-status', platform, running: false });
    updateLiveFromMultistream();
    if (!wasIntentional && msLive && msPrefs[platform]) {
      setTimeout(() => startPush(platform), 3000);
    }
  });
}

function stopPush(platform) {
  const entry = msProcesses[platform];
  if (entry && entry.running) {
    entry.intentionalStop = true;
    entry.proc.kill('SIGINT');
  }
}

// Chamado pelo nginx (on_publish) quando o OBS comeca a transmitir
app.post('/api/multistream/on-publish', (req, res) => {
  msLive = true;
  msStreamName = req.body.name || 'live';
  console.log(`Multistream: OBS comecou a publicar em '${msStreamName}', iniciando plataformas habilitadas`);
  Object.keys(msPrefs).forEach((platform) => { if (msPrefs[platform]) startPush(platform); });
  res.sendStatus(200);
});

// Chamado pelo nginx (on_publish_done) quando o OBS para de transmitir
app.post('/api/multistream/on-publish-done', (req, res) => {
  msLive = false;
  console.log('Multistream: OBS parou de publicar, encerrando todos os pushes');
  Object.keys(msProcesses).forEach(stopPush);
  msStreamName = null;
  res.sendStatus(200);
});

app.get('/api/multistream/state', (req, res) => {
  const platforms = {};
  Object.keys(msPrefs).forEach((platform) => {
    platforms[platform] = {
      enabled: msPrefs[platform],
      running: !!(msProcesses[platform] && msProcesses[platform].running),
      configured: !!(MS_DESTINATIONS[platform] && MS_DESTINATIONS[platform]()),
    };
  });
  res.json({ live: msLive, platforms });
});

app.post('/api/multistream/:platform/toggle', requireKey, (req, res) => {
  const platform = req.params.platform;
  if (!(platform in msPrefs)) return res.status(400).json({ error: 'plataforma desconhecida' });
  const { enabled } = req.body;
  msPrefs[platform] = !!enabled;
  saveMsPrefs();

  if (msLive) {
    if (enabled) startPush(platform);
    else stopPush(platform);
  }
  res.json({ ok: true, prefs: msPrefs });
});

// ---------- "Quem esta ao vivo": deriva direto do status real do multistream ----------
function updateLiveFromMultistream() {
  const platforms = Object.keys(msProcesses).filter((p) => msProcesses[p].running);
  const state = readState();
  const current = state.live.platforms || [];
  const changed =
    current.length !== platforms.length || !current.every((p) => platforms.includes(p));
  if (changed) {
    state.live = { platforms, updatedAt: new Date().toISOString() };
    writeState(state);
    console.log('Plataformas ao vivo agora:', platforms.length ? platforms.join(', ') : '(nenhuma)');
  }
}

// =====================================================================
// Troca automatica de camera: monitora os 2 paths do MediaMTX (celular
// principal e secundario) e troca a cena no OBS sozinho quando o
// principal cai, usando o segundo celular em vez de ir direto pra BRB.
// =====================================================================
const OBSWebSocketModule = require('obs-websocket-js');
const OBSWebSocket = OBSWebSocketModule.default || OBSWebSocketModule.OBSWebSocket || OBSWebSocketModule;

const OBS_WS_URL = process.env.OBS_WEBSOCKET_URL || 'ws://192.168.15.2:4455';
const OBS_WS_PASSWORD = process.env.OBS_WEBSOCKET_PASSWORD || '';
const CAM_PRIMARY_PATH = process.env.CAM_PRIMARY_PATH || 'live';
const CAM_SECONDARY_PATH = process.env.CAM_SECONDARY_PATH || 'irl';
const SCENE_LIVE = process.env.OBS_SCENE_LIVE || 'LIVE';
const SCENE_CAM2 = process.env.OBS_SCENE_CAM2 || 'CAM2';
const SCENE_BRB = process.env.OBS_SCENE_BRB || 'BRB';
const MEDIAMTX_API = process.env.MEDIAMTX_API || 'http://127.0.0.1:9997';

const CAMERA_FAILOVER_STATE_PATH = path.join(__dirname, 'camera-failover-state.json');
let cfPrefs = { enabled: true };
if (fs.existsSync(CAMERA_FAILOVER_STATE_PATH)) {
  cfPrefs = { ...cfPrefs, ...JSON.parse(fs.readFileSync(CAMERA_FAILOVER_STATE_PATH, 'utf8')) };
}
function saveCfPrefs() { fs.writeFileSync(CAMERA_FAILOVER_STATE_PATH, JSON.stringify(cfPrefs, null, 2)); }

const obs = new OBSWebSocket();
let obsConnected = false;

// Cena atual real do OBS, sempre em dia - atualizada tanto quando o failover
// troca de cena quanto quando voce troca manualmente (evento nativo do OBS).
// Usado pelo overlay pra saber, por exemplo, quando esconder o GPS.
let currentSceneName = null;

async function connectObs() {
  try {
    await obs.connect(OBS_WS_URL, OBS_WS_PASSWORD || undefined);
    obsConnected = true;
    console.log('Camera failover: conectado ao OBS WebSocket');
    try {
      const { currentProgramSceneName } = await obs.call('GetCurrentProgramScene');
      currentSceneName = currentProgramSceneName;
      console.log('Cena atual (ao conectar):', currentSceneName);
    } catch (e) {
      console.error('Erro pegando cena atual:', e.message);
    }
  } catch (e) {
    obsConnected = false;
    console.error('Camera failover: erro conectando no OBS:', e.message);
  }
}
obs.on('CurrentProgramSceneChanged', (data) => {
  currentSceneName = data.sceneName;
  console.log('Cena trocou para:', currentSceneName);
});
obs.on('ConnectionClosed', () => {
  if (obsConnected) console.log('Camera failover: conexao com OBS caiu, tentando reconectar...');
  obsConnected = false;
  setTimeout(connectObs, 5000);
});
connectObs();

let cfPrimaryOnline = false;
let cfSecondaryOnline = false;
let cfCurrentScene = null;
let cfPendingScene = null;
let cfPendingSince = 0;
const CF_DEBOUNCE_MS = 5000;

async function checkMediaMtxPaths() {
  try {
    const resp = await fetch(`${MEDIAMTX_API}/v3/paths/list`);
    const data = await resp.json();
    const items = data.items || [];
    const primary = items.find((p) => p.name === CAM_PRIMARY_PATH);
    const secondary = items.find((p) => p.name === CAM_SECONDARY_PATH);
    cfPrimaryOnline = !!(primary && primary.ready);
    cfSecondaryOnline = !!(secondary && secondary.ready);
  } catch (e) {
    console.error('Camera failover: erro consultando MediaMTX:', e.message);
    cfPrimaryOnline = false;
    cfSecondaryOnline = false;
  }
}

function desiredScene() {
  if (cfPrimaryOnline) return SCENE_LIVE;
  if (cfSecondaryOnline) return SCENE_CAM2;
  return SCENE_BRB;
}

async function evaluateCameraFailover() {
  if (!cfPrefs.enabled || !obsConnected) return;
  await checkMediaMtxPaths();
  const target = desiredScene();

  if (target !== cfPendingScene) {
    cfPendingScene = target;
    cfPendingSince = Date.now();
    return;
  }

  const stableFor = Date.now() - cfPendingSince;
  if (target !== cfCurrentScene && stableFor >= CF_DEBOUNCE_MS) {
    try {
      await obs.call('SetCurrentProgramScene', { sceneName: target });
      cfCurrentScene = target;
      console.log(`Camera failover: trocou pra cena '${target}'`);
    } catch (e) {
      console.error('Camera failover: erro trocando de cena:', e.message);
    }
  }
}
setInterval(evaluateCameraFailover, 3000);

app.get('/api/camera-failover/state', (req, res) => {
  res.json({
    enabled: cfPrefs.enabled,
    obsConnected,
    currentScene: cfCurrentScene,
    primary: { path: CAM_PRIMARY_PATH, online: cfPrimaryOnline },
    secondary: { path: CAM_SECONDARY_PATH, online: cfSecondaryOnline },
  });
});

app.post('/api/camera-failover/toggle', requireKey, (req, res) => {
  cfPrefs.enabled = !!req.body.enabled;
  saveCfPrefs();
  res.json({ ok: true, enabled: cfPrefs.enabled });
});

// Reconcilia o estado "ao vivo" ja na inicializacao (evita ficar travado
// num estado antigo se o servidor reiniciar com a live aberta)
updateLiveFromMultistream();
setInterval(updateLiveFromMultistream, 30000);

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Overlay hub rodando em http://0.0.0.0:${PORT}`);
  console.log(`Overlay (adicionar no OBS):  http://SEU_IP:${PORT}/overlay`);
  console.log(`Painel de controle:          http://SEU_IP:${PORT}/control?key=${CONTROL_KEY}`);
});
