# Overlay Hub — enzocn_

Overlay único (IRL) com painel de controle web, rodando num servidor Node.js
próprio. Inclui:

- Logo com animação de pulsação (esquerda/direita)
- Widget de clima/data/hora (busca o clima pela posição do GPS quando disponível,
  senão usa uma cidade fixa)
- QR code fixo (com ciclo opcional de aparecer 10s / esconder 1min)
- Contador de plataforma(s) ao vivo (Twitch/Kick/YouTube), detectado pelo status
  real do multistream (não por polling de API)
- GPS: mapa com 1+ celulares em tempo real (WebSocket) + rota opcional,
  só aparece nas cenas configuradas (padrão: LIVE e LOW) e só quando há
  pelo menos um celular ativo
- Multistream: um único RTMP do OBS é empurrado via ffmpeg para
  Twitch/Kick/YouTube simultaneamente, cada um ligável/desligável pelo painel
- Troca automática de câmera: monitora 2 câmeras (via MediaMTX) e troca a cena
  do OBS sozinho quando a principal cai, via OBS WebSocket

## 1. Instalar

```bash
cd overlay-hub
npm install
cp .env.example .env
nano .env   # preencha as chaves/URLs que for usar (veja a seção abaixo)
npm start
```

Sobe em `http://0.0.0.0:8090` por padrão.

Dependências de sistema (fora do npm):
- **ffmpeg** — usado pelo multistream (`sudo apt install ffmpeg`)
- **nginx com módulo RTMP** ou **MediaMTX** — recebe o RTMP do OBS
- **OBS WebSocket** habilitado no OBS (Ferramentas → WebSocket Server Settings)

## 2. Variáveis de ambiente

Veja `.env.example` para a lista completa. Nada é obrigatório além de
`CONTROL_KEY` — cada bloco de funcionalidade (GPS, multistream, clima, câmera)
só liga se as variáveis dele estiverem preenchidas; sem elas, essa parte fica
inerte e o resto do overlay funciona normal.

## 3. Adicionar no OBS

**Fonte de navegador (Browser Source):** `http://IP_DO_SERVIDOR:8090/overlay`

Depois de qualquer atualização no `overlay.html` no servidor, clique com o
botão direito na fonte → Propriedades → **"Atualizar cache do navegador
atual"** — o Browser Source do OBS não recarrega sozinho quando o arquivo
muda no disco.

## 4. Painel de controle

```
http://IP_DO_SERVIDOR:8090/control?key=SUA_CONTROL_KEY
```

Esse painel é a interface que fica direto no servidor (não faz parte deste
repositório — evoluiu bastante e é mantido separadamente).

## 5. Rodando sempre ligado (systemd)

```ini
# /etc/systemd/system/overlay-hub.service
[Unit]
Description=Overlay Hub
After=network.target

[Service]
WorkingDirectory=/home/enzo/overlay-hub
ExecStart=/usr/bin/node server.js
Restart=always
User=enzo

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now overlay-hub
```

## 6. Sobre o GitHub

- **Não** commite o `.env` (tem suas chaves) — o `.gitignore` já impede isso.
- `state.json` e os arquivos `gps-*.json`, `multistream-state.json`,
  `camera-failover-state.json` também ficam de fora — são gerados/atualizados
  pelo próprio servidor em runtime.
